import { FormEvent, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { ShieldCheck } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";

export function AdminLoginPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!loading && user) return <Navigate to="/admin/mfa" replace />;

  async function submit(event: FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
    setSubmitting(false);
    if (signInError) {
      setError("Credenciais inválidas");
      return;
    }
    navigate("/admin/mfa", { replace: true });
  }

  return (
    <div className="access-page admin-access-page">
      <section className="access-card">
        <div className="brand-lockup access-brand">
          <div className="brand-mark">MRL</div>
          <div><strong>MRL Travel</strong><span>Painel administrativo</span></div>
        </div>
        <form onSubmit={submit} className="access-form">
          <div className="access-icon"><ShieldCheck /></div>
          <h1>Acesso da equipe</h1>
          <p>Esta área exige credencial administrativa e autenticação em dois fatores.</p>
          <label htmlFor="adminEmail">E-mail</label>
          <input id="adminEmail" type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="username" required />
          <label htmlFor="adminPassword">Senha</label>
          <input id="adminPassword" type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" required />
          {error && <div className="form-error" role="alert">{error}</div>}
          <button className="primary-button" disabled={submitting}>{submitting ? "Entrando..." : "Continuar"}</button>
        </form>
      </section>
    </div>
  );
}
